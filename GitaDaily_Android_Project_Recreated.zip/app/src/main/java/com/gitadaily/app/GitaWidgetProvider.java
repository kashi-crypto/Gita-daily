package com.gitadaily.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

public class GitaWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    private static void update(Context context, AppWidgetManager manager, int id) {
        GitaVerse v = GitaData.today();
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.gita_widget);
        views.setTextViewText(R.id.widget_reference, v.reference);
        views.setTextViewText(R.id.widget_meaning, v.meaning);
        manager.updateAppWidget(id, views);
    }
}
