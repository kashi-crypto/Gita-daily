package com.gitadaily.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        GitaVerse v = GitaData.today();
        ((TextView)findViewById(R.id.reference)).setText(v.reference);
        ((TextView)findViewById(R.id.transliteration)).setText(v.transliteration);
        ((TextView)findViewById(R.id.meaning)).setText(v.meaning);
    }
}
