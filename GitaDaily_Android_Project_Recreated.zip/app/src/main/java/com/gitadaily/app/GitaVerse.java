package com.gitadaily.app;

public class GitaVerse {
    public final String reference, transliteration, meaning;
    public GitaVerse(String reference, String transliteration, String meaning) {
        this.reference = reference;
        this.transliteration = transliteration;
        this.meaning = meaning;
    }
}
