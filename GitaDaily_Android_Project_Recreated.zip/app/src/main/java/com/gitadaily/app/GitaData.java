package com.gitadaily.app;

import java.util.Calendar;

public class GitaData {
    // Starter set. The app is structured so the remaining verses can be added here
    // without changing the widget or UI code.
    private static final GitaVerse[] VERSES = {
        new GitaVerse("Bhagavad Gita 2.47",
            "Karmany evadhikaras te ma phalesu kadacana",
            "You have a right to your work, but not to the fruits of your actions. Do not let the results be the sole motive for your work."),
        new GitaVerse("Bhagavad Gita 2.48",
            "Yogasthah kuru karmani sangam tyaktva dhananjaya",
            "Established in yoga, perform your duties, giving up attachment to success and failure. Such balance is called yoga."),
        new GitaVerse("Bhagavad Gita 2.50",
            "Buddhiyukto jahatiha ubhe sukrtaduskrte",
            "One who is united with wisdom lets go of attachment to both good and bad results. Therefore, seek this discipline of understanding."),
        new GitaVerse("Bhagavad Gita 4.7",
            "Yada yada hi dharmasya glanir bhavati bharata",
            "Whenever righteousness declines and unrighteousness rises, the Divine manifests to restore balance and dharma."),
        new GitaVerse("Bhagavad Gita 4.8",
            "Paritranaya sadhunam vinasaya ca duskrtam",
            "To protect the righteous, restrain destructive forces, and re-establish dharma, the Divine appears age after age."),
        new GitaVerse("Bhagavad Gita 6.5",
            "Uddhared atmanatmanam natmanam avasadayet",
            "Let a person uplift themselves by their own disciplined mind and not allow themselves to fall into discouragement."),
        new GitaVerse("Bhagavad Gita 6.6",
            "Bandhur atmatmanas tasya yenatmaivatmana jitah",
            "For one who has mastered the mind, the mind is a friend; for one who has not, the mind can act as an enemy."),
        new GitaVerse("Bhagavad Gita 9.22",
            "Ananyas cintayanto mam ye janah paryupasate",
            "Those who remain devoted to the Divine with steady attention are cared for in what they need and are protected in what they have."),
        new GitaVerse("Bhagavad Gita 12.13",
            "Advestā sarva-bhutanam maitrah karuna eva ca",
            "One who bears no hatred toward any being, who is friendly and compassionate, and who is free from possessiveness and ego is dear to the Divine."),
        new GitaVerse("Bhagavad Gita 12.14",
            "Santustah satatam yogi yatatma drdha-niscayah",
            "Content, disciplined, steady in practice, and firm in resolve, such a person remains devoted and balanced."),
        new GitaVerse("Bhagavad Gita 18.63",
            "Iti te jnanam akhyatam guhyad guhyataram maya",
            "Thus I have explained knowledge that is more profound than what is ordinarily revealed. Reflect on it fully, and then act as you choose."),
        new GitaVerse("Bhagavad Gita 18.65",
            "Man-mana bhava mad-bhakto mad-yaji mam namaskuru",
            "Keep your mind directed toward the Divine, cultivate devotion, offer your actions, and live with reverence; this is presented as a path of devotion."),
        new GitaVerse("Bhagavad Gita 18.66",
            "Sarva-dharman parityajya mam ekam saranam vraja",
            "Take refuge in the Divine alone, letting go of every limiting attachment. Do not be overcome by fear or despair."),
        new GitaVerse("Bhagavad Gita 18.78",
            "Yatra yogesvarah krsno yatra partho dhanur-dharah",
            "Where there is Krishna, the master of yoga, and Arjuna, the dedicated seeker and archer, there are lasting strength, prosperity, victory, and sound judgment."),
        new GitaVerse("Bhagavad Gita 3.19",
            "Tasmad asaktah satatam karyam karma samacara",
            "Therefore, perform the work that ought to be done without attachment. By acting without clinging to results, one moves toward the highest."),
    };

    public static GitaVerse today() {
        Calendar c = Calendar.getInstance();
        int day = c.get(Calendar.DAY_OF_YEAR);
        return VERSES[(day - 1) % VERSES.length];
    }
}
